package pkg.controllori;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import pkg.dao.LibreriaDAO;
import pkg.entita.CategoriaBasic;
import pkg.entita.CorsoNewForm;
import pkg.entita.CorsoRicerca;
import pkg.entita.CorsoSearch;
import pkg.entita.LoginForm;
import pkg.entita.RecensioneForm;
import pkg.entita.Regione;
import pkg.entita.SearchForm;
import pkg.entita.Stato;
import pkg.entita.Utente;
import pkg.entita.UtenteEditForm;

@Controller
public class DefaultController {

    @Autowired
    private LibreriaDAO dao;

    @Autowired
    private Utente utente;

//    public void setDao(DaoPersona dao) {
//        this.dao = dao;
//    }
    // RADICE del Sito
    @RequestMapping(value = "/")
    public String root(ModelMap map) {
        return "redirect:/index"; //reindirizza alla Home Page
    }

    @RequestMapping(value = "/home")
    public String home(ModelMap map) {
        return "redirect:/index"; //reindirizza alla Home Page
    }

    // Home Page 
    @RequestMapping(value = "/index")
    public String index(ModelMap map) {
        return "redirect:/viewHome";
    }

    @RequestMapping(value = "/viewHome", method = RequestMethod.GET)
    public String viewHome(@ModelAttribute SearchForm searchForm, Model model) {
        //check if utente login
        model.addAttribute(utente);

        model.addAttribute("searchForm", searchForm);

        List<Stato> listaStati = dao.listaStati();
        Map<String, String> stati = new LinkedHashMap<String, String>();
        stati.put("-1", "");

        for (Stato x : listaStati) {
            stati.put(Integer.toString(x.getIdStato()), x.getNomeStato());
        };

        List<CategoriaBasic> listaCategorie = dao.listaCategorie();
        Map<String, String> categorie = new LinkedHashMap<String, String>();
        categorie.put("-1", "");
        for (CategoriaBasic x : listaCategorie) {
            categorie.put(Integer.toString(x.getIdCategoria()), x.getCategoria());
        };

        Map<String, String> regioni = new LinkedHashMap<String, String>();
        regioni.put("-1", "");

        model.addAttribute("statiList", stati);
        model.addAttribute("categorieList", categorie);
        model.addAttribute("regioniList", regioni);

        //DATI
        int nCorsi = dao.numeroCorsi();
        int nUtenti = dao.numeroUtenti();
        int nRecensioni = dao.numeroRecensioni();

        model.addAttribute("nUtenti", nUtenti);
        model.addAttribute("nRecensioni", nRecensioni);
        model.addAttribute("nCorsi", nCorsi);

        //DA FINIRE AJAX
        model.addAttribute("corsi", dao.listaCorsiHome());

        //5 corsi ultimi?
        //3 valori sito
        return "viewHome";
    }

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login(@ModelAttribute LoginForm loginForm, Model model) {
        model.addAttribute("loginForm", loginForm);
        return "viewLogin";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout(Model model) {
        utente.logout();
        return "redirect:/viewHome";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String loginPost(@ModelAttribute LoginForm loginForm, Model model) {

        if (dao.isRegistred(loginForm.getEmail())) {//login
            Utente u = dao.utenteByEmail(loginForm.getEmail());
            if (u.getPassword().equals(loginForm.getPassword())) {
                utente = u;
                utente.login();
                return "redirect:/viewHome";
            } else {
                loginForm.setPassword("");
                return "viewLogin";
            }

        } else if (!loginForm.getEmail().equals("")) { //registrazione
            if (!loginForm.getPassword().equals(loginForm.getRepassword())) {
                loginForm.setPassword("");
                loginForm.setRepassword("");
                model.addAttribute("loginForm", loginForm);
                return "viewLogin";
            }
            dao.addUtente(loginForm.getEmail(),
                    "",
                    loginForm.getNome(),
                    loginForm.getCognome(),
                    "",
                    loginForm.getPassword());
            utente = dao.utenteByEmail(loginForm.getEmail());
            utente.login();
            return "redirect:/viewHome";
        } else {
            return "viewLogin";
        }
    }

    @RequestMapping(value = "/isRegistred", method = RequestMethod.GET)
    public String checkRegistration(@RequestParam("email") String email, Model model) {

        if (dao.isRegistred(email)) {
            model.addAttribute("value", 1);
        } else {
            model.addAttribute("value", 0);
        }
        return "AJAX";
    }

    @RequestMapping(value = "/getRegioni", method = RequestMethod.GET)
    public String getRegioni(@RequestParam("idStato") String idStato, Model model) {
        List<Regione> r = dao.listaRegioniByStato(idStato);
        StringBuilder sb = new StringBuilder("<option value=\"-1\"></option>");
        for (Regione x : r) {
            sb.append("<option value=\"").append(x.getIdRegione()).append("\">");
            sb.append(x.getNomeRegione());
            sb.append("</option>");
        }
        model.addAttribute("value", sb.toString());

        return "AJAX";
    }

    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public String search(@ModelAttribute SearchForm searchForm, Model model) {
        model.addAttribute(utente);
        List<Stato> listaStati = dao.listaStati();
        Map<String, String> stati = new LinkedHashMap<String, String>();
        stati.put("-1", "");

        for (Stato x : listaStati) {
            stati.put(Integer.toString(x.getIdStato()), x.getNomeStato());
        };

        List<CategoriaBasic> listaCategorie = dao.listaCategorie();
        Map<String, String> categorie = new LinkedHashMap<String, String>();
        categorie.put("-1", "");
        for (CategoriaBasic x : listaCategorie) {
            categorie.put(Integer.toString(x.getIdCategoria()), x.getCategoria());
        };

        Map<String, String> regioni = new LinkedHashMap<String, String>();
        regioni.put("-1", "");
        if (searchForm.getStato() != null && !searchForm.getStato().equals("-1")) {
            List<Regione> r = dao.listaRegioniByStato(String.valueOf(searchForm.getStato()));
            for (Regione x : r) {
                System.out.println(x.getNomeRegione());
                regioni.put(Integer.toString(x.getIdRegione()), x.getNomeRegione());
            };
        }

        model.addAttribute("statiList", stati);
        model.addAttribute("categorieList", categorie);
        model.addAttribute("regioniList", regioni);

        model.addAttribute("corsi",
                dao.listaCorsiRicerca(
                        searchForm.getQuery(),
                        searchForm.getCategoria(),
                        searchForm.getStato(),
                        searchForm.getRegione()
                ));
        model.addAttribute("searchForm", searchForm);
        return "viewSearch";
    }

    @RequestMapping(value = "/corso/{id}", method = RequestMethod.GET)
    public String corso(@PathVariable("id") int id, Model model) {
        model.addAttribute(utente);
        model.addAttribute("recensioni", dao.listaRecensioniByIdCorso(id));
        model.addAttribute("corso", dao.corsoRicercaById(id));
        model.addAttribute("recensioneForm", new RecensioneForm(id));
        return "viewCorso";
    }

    @RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
    public String utente(@PathVariable("id") int id, Model model) {
        model.addAttribute(utente);
        model.addAttribute("user", dao.utenteById(id));
        model.addAttribute("recensioni", dao.listaRecensioniByUtente(id));
        return "viewUser";
    }

    @RequestMapping(value = "/editUser", method = RequestMethod.GET)
    public String editUser(Model model) {
        model.addAttribute(utente);
        if (!utente.isIsLogged()) {
            return "redirect:/login";
        }
        System.out.println(utente);
        model.addAttribute("utenteEditForm", new UtenteEditForm(utente));
        return "viewUserEdit";
    }

    @RequestMapping(value = "/updateUser", method = RequestMethod.POST)
    public String updateUserPost(@ModelAttribute UtenteEditForm utenteEditForm, Model model) {

        if (!utenteEditForm.getPassword().equals(utenteEditForm.getRepassword())) {
            return "redirect:/editUser";
        } else {
            if (utenteEditForm.getPassword().equals("")) {
                utenteEditForm.setPassword(utente.getPassword());
            }
            dao.updateUser(utenteEditForm.getId(), utenteEditForm.getNome(), utenteEditForm.getCognome(), utenteEditForm.getPassword());
            utente = dao.utenteById(utenteEditForm.getId());
            utente.login();
        }

        return "redirect:/viewHome";
    }

    @RequestMapping(value = "/addRecensione", method = RequestMethod.POST)
    public String addRecensione(@ModelAttribute RecensioneForm recensioneForm, Model model) {

        if (!utente.isLogged()) {
            return "redirect:/viewHome";
        } else {
            dao.addRecensione(
                    recensioneForm.getIdCorso(),
                    utente.getId(),
                    recensioneForm.getTitolo(),
                    recensioneForm.getDescrizione(),
                    recensioneForm.getData(),
                    recensioneForm.getValutazione());
        }

        return "redirect:/corso/" + recensioneForm.getIdCorso();
    }

    @RequestMapping(value = "/addCorso", method = RequestMethod.GET)
    public String addCorso(@ModelAttribute CorsoNewForm corsoNewForm, Model model) {

        if (!utente.isLogged()) {
            return "redirect:/viewHome";
        } else {
            model.addAttribute("corsoNewForm", new CorsoNewForm());

            List<CategoriaBasic> listaCategorie = dao.listaCategorie();
            Map<String, String> categorie = new LinkedHashMap<String, String>();
            for (CategoriaBasic x : listaCategorie) {
                categorie.put(Integer.toString(x.getIdCategoria()), x.getCategoria());
            };

            Map<String, String> regioni = new LinkedHashMap<String, String>();
            List<Regione> r = dao.listaRegioni();
            for (Regione x : r) {
                System.out.println(x.getNomeRegione());
                regioni.put(Integer.toString(x.getIdRegione()), x.getNomeRegione());
            };

            model.addAttribute("categorieList", categorie);
            model.addAttribute("regioniList", regioni);
            model.addAttribute(utente);
        }

        return "viewCorsoAdd";
    }
    
    @RequestMapping(value = "/addCorso", method = RequestMethod.POST)
    public String addCorsoPost(@ModelAttribute CorsoNewForm corsoNewForm, Model model) {
        int i;
        if (!utente.isLogged()) {
            return "redirect:/viewHome";
        } else {
            i = dao.addCorso(
                    corsoNewForm.getTitolo(),
                    corsoNewForm.getDescrizione(),
                    corsoNewForm.getCoordinate(),
                    corsoNewForm.getRegione(),
                    corsoNewForm.getCategoria(),
                    corsoNewForm.getIndirizzo(),
                    corsoNewForm.getDurata());
        }

        return "redirect:/corso/"+i;
    }
}
