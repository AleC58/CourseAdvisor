package pkg.dao;

import pkg.entita.Corso;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import pkg.entita.CategoriaBasic;
import pkg.entita.CorsoHome;
import pkg.entita.CorsoBasic;
import pkg.entita.CorsoRicerca;
import pkg.entita.RecensioneCorso;
import pkg.entita.RecensioneUtente;
import pkg.entita.Regione;
import pkg.entita.Stato;
import pkg.entita.Utente;

public class LibreriaDAO {

    private DataSource dataSource;
    private JdbcTemplate jdbcTemplate;

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public Corso corsoById(int id) {

        Corso corso = this.jdbcTemplate.queryForObject(
                "SELECT *\n"
                + "FROM Corso \n"
                + "WHERE Corso.idCorso = " + id + ";",
                new Object[]{1212L},
                new RowMapper<Corso>() {
            @Override
            public Corso mapRow(ResultSet rs, int rowNum) throws SQLException {
                Corso corso = new Corso();
                corso.setByDB(rs.getInt("idCorso"),
                        rs.getString("titolo"),
                        rs.getString("descrizione"),
                        rs.getString("coordinate"),
                        rs.getString("indirizzo"),
                        rs.getInt("durata"),
                        regioneById(rs.getInt("fkIdRegione")),
                        categoriaById(rs.getInt("fkIdCategoria")));
                return corso;
            }
        });
        return corso;
    }

    public Regione regioneById(int id) {
        Regione regione = this.jdbcTemplate.queryForObject(
                "SELECT *\n"
                + "FROM Regione \n"
                + "WHERE Regione.idRegione = " + id + ";",
                new Object[]{1212L},
                new RowMapper<Regione>() {
            @Override
            public Regione mapRow(ResultSet rs, int rowNum) throws SQLException {
                Regione regione = new Regione();
                regione.setByDB(rs.getInt("idRegione"),
                        rs.getString("nomeRegione"),
                        statoById(rs.getInt("fdkIdStato")));
                return regione;
            }
        });
        return regione;
    }

    public Stato statoById(int id) {
        Stato stato = this.jdbcTemplate.queryForObject(
                "SELECT *\n"
                + "FROM Stato \n"
                + "WHERE Stato.idStato = " + id + ";",
                new Object[]{1212L},
                new RowMapper<Stato>() {
            @Override
            public Stato mapRow(ResultSet rs, int rowNum) throws SQLException {
                Stato stato = new Stato();
                stato.setByDB(rs.getInt("idStato"),
                        rs.getString("nomeStato"));
                return stato;
            }
        });
        return stato;
    }

    public CategoriaBasic categoriaById(int id) {
        CategoriaBasic categoria = this.jdbcTemplate.queryForObject("SELECT *\n"
                + "FROM Categoria \n"
                + "WHERE Categoria.idCategoria = " + id + ";",
                new Object[]{1212L},
                new RowMapper<CategoriaBasic>() {
            @Override
            public CategoriaBasic mapRow(ResultSet rs, int rowNum) throws SQLException {
                CategoriaBasic categoria = new CategoriaBasic();
                categoria.setByDB(rs.getInt("idCategoria"),
                        rs.getString("nomeCategoria"));
                return categoria;
            }
        });
        return categoria;
    }

    public List<CorsoBasic> listaCorsi() {
        List<CorsoBasic> corsi = this.jdbcTemplate.query("SELECT Corso.idCorso, Corso.titolo\n"
                + "FROM Corso;",
                new RowMapper<CorsoBasic>() {
            @Override
            public CorsoBasic mapRow(ResultSet rs, int rowNum) throws SQLException {
                CorsoBasic corso = new CorsoBasic(rs.getInt("idCorso"),
                        rs.getString("titolo"));
                return corso;
            }
        });
        return corsi;
    }

    public List<Stato> listaStati() {
        List<Stato> stati = this.jdbcTemplate.query(
                "SELECT idStato, nomeStato\n"
                + "FROM Stato; ",
                new RowMapper<Stato>() {
            @Override
            public Stato mapRow(ResultSet rs, int rowNum) throws SQLException {
                Stato stato = new Stato();
                stato.setByDB(
                        rs.getInt("idStato"),
                        rs.getString("nomeStato")
                );
                return stato;
            }
        });
        return stati;
    }

    public List<CategoriaBasic> listaCategorie() {
        List<CategoriaBasic> categorie = this.jdbcTemplate.query("SELECT idCategoria, nomeCategoria\n"
                + "FROM Categoria; ",
                new RowMapper<CategoriaBasic>() {
            @Override
            public CategoriaBasic mapRow(ResultSet rs, int rowNum) throws SQLException {
                CategoriaBasic categoria = new CategoriaBasic();
                categoria.setByDB(
                        rs.getInt("idCategoria"),
                        rs.getString("nomeCategoria")
                );
                return categoria;
            }
        });
        return categorie;
    }

    public List<CorsoHome> listaCorsiHome() {
        List<CorsoHome> corsi = this.jdbcTemplate.query(
                "SELECT idCorso, titolo, descrizione, (Stato.nomeStato || ',' || Regione.nomeRegione) as Posizione\n"
                + "FROM Corso INNER JOIN Regione ON Corso.fkIdRegione = Regione.idRegione\n"
                + "INNER JOIN Stato ON Regione.fkIdStato = Stato.idStato\n"
                + "LIMIT 5; ",
                new RowMapper<CorsoHome>() {
            @Override
            public CorsoHome mapRow(ResultSet rs, int rowNum) throws SQLException {
                CorsoHome corso = new CorsoHome(
                        rs.getInt("idCorso"),
                        rs.getString("titolo"),
                        rs.getString("descrizione"),
                        rs.getString("Posizione")
                );
                return corso;
            }
        });
        return corsi;
    }

    public List<RecensioneCorso> listaRecensioniByIdCorso(int id) {
        List<RecensioneCorso> recensioneId = this.jdbcTemplate.query("SELECT Recensione.idRecensione, Recensione.titolo, Recensione.commento, Recensione.dataFrequentazione, Recensione.valutazione, Utente.idUtente, Utente.cognome, Utente.nome, Utente.foto\n"
                + "FROM Recensione INNER JOIN Utente ON Recensione.fkIdUtente = Utente.idUtente\n"
                + "WHERE Recensione.fkIdCorso = " + id + ";",
                new RowMapper<RecensioneCorso>() {
            @Override
            public RecensioneCorso mapRow(ResultSet rs, int rowNum) throws SQLException {
                RecensioneCorso recensioneId = new RecensioneCorso(
                        rs.getInt("idRecensione"),
                        rs.getInt("idUtente"),
                        rs.getString("titolo"),
                        rs.getInt("valutazione"),
                        rs.getString("commento"),
                        rs.getString("dataFrequentazione"),
                        rs.getString("cognome"),
                        rs.getString("nome"),
                        rs.getString("foto")
                );
                return recensioneId;
            }
        });
        return recensioneId;
    }

    public List<RecensioneUtente> listaRecensioniByUtente(int id) {
        List<RecensioneUtente> recensioneUtente = this.jdbcTemplate.query(
                "SELECT Recensione.idRecensione, Recensione.titolo as RecTitolo, Corso.idCorso, Corso.titolo, Recensione.valutazione, Recensione.dataFrequentazione, Recensione.commento\n"
                + "FROM Recensione INNER JOIN Corso ON Recensione.fkIdCorso = Corso.idCorso\n"
                + "WHERE Recensione.fkIdUtente = " + id + ";",
                new RowMapper<RecensioneUtente>() {
            @Override
            public RecensioneUtente mapRow(ResultSet rs, int rowNum) throws SQLException {
                RecensioneUtente recensioneUtente = new RecensioneUtente(
                        rs.getInt("idRecensione"),
                        rs.getString("RecTitolo"),
                        rs.getInt("idCorso"),
                        rs.getString("titolo"),
                        rs.getInt("valutazione"),
                        rs.getString("commento"),
                        rs.getString("dataFrequentazione")
                );
                return recensioneUtente;
            }
        });
        return recensioneUtente;
    }

    public List<Regione> listaRegioniByStato(String id) {
        Stato a = new Stato();
        List<Regione> regione = this.jdbcTemplate.query(
                "SELECT Regione.idRegione, Regione.nomeRegione\n"
                + "FROM Regione\n"
                + "WHERE Regione.fkIdStato = " + id + ";",
                new RowMapper<Regione>() {
            @Override
            public Regione mapRow(ResultSet rs, int rowNum) throws SQLException {
                Regione regione = new Regione();
                regione.setByDB(
                        rs.getInt("idRegione"),
                        rs.getString("nomeRegione"),
                        new Stato()
                );
                return regione;
            }
        });
        return regione;
    }

    public List<CorsoRicerca> listaCorsiRicerca(String titolo, String idCategoria, String idStato, String idRegione) {
        StringBuilder sb = new StringBuilder("SELECT idCorso, titolo, Corso.descrizione, foto,\n"
                + "Categoria.nomeCategoria, Corso.coordinate, Corso.durata, Corso.indirizzo,\n"
                + "Stato.nomeStato, Regione.nomeRegione\n"
                + "FROM Corso INNER JOIN Regione ON Corso.fkIdRegione = Regione.idRegione \n"
                + "INNER JOIN Stato ON Regione.fkIdStato = Stato.idStato\n"
                + "INNER JOIN Categoria ON Corso.fkIdCategoria = Categoria.idCategoria\n"
                + "WHERE 1=1 ");
        System.out.println(titolo.isEmpty());
        if (titolo != null && !titolo.equals("")) {
            sb.append("AND Corso.titolo LIKE '%").append(titolo).append("%'");
        }
        if (idCategoria != null && !idCategoria.equals("-1")) {
            sb.append(" AND Corso.fkIdCategoria=").append(idCategoria);
        }

        if (idRegione != null && !idRegione.equals("-1")) {
            sb.append(" AND Corso.fkIdRegione=").append(idRegione);
        }

        if (idStato != null && !idStato.equals("-1")) {
            sb.append(" AND Regione.fkIdStato=").append(idStato);
        }

        List<CorsoRicerca> corsoRicerca = this.jdbcTemplate.query(sb.toString(),
                new RowMapper<CorsoRicerca>() {
            @Override
            public CorsoRicerca mapRow(ResultSet rs, int rowNum) throws SQLException {
                CorsoRicerca corsoRicerca = new CorsoRicerca(rs.getInt("idCorso"),
                        rs.getString("titolo"),
                        rs.getString("descrizione"),
                        rs.getString("nomeCategoria"),
                        rs.getString("coordinate"),
                        rs.getString("durata"),
                        rs.getString("indirizzo"),
                        rs.getString("nomeStato"),
                        rs.getString("nomeRegione"),
                        rs.getString("foto")
                );
                return corsoRicerca;
            }
        }
        );
        return corsoRicerca;
    }

    public CorsoRicerca corsoRicercaById(int id) {

        String sb = "SELECT idCorso, titolo, Corso.descrizione, foto,\n"
                + "Categoria.nomeCategoria, Corso.coordinate, Corso.durata, Corso.indirizzo,\n"
                + "Stato.nomeStato, Regione.nomeRegione\n"
                + "FROM Corso INNER JOIN Regione ON Corso.fkIdRegione = Regione.idRegione \n"
                + "INNER JOIN Stato ON Regione.fkIdStato = Stato.idStato\n"
                + "INNER JOIN Categoria ON Corso.fkIdCategoria = Categoria.idCategoria WHERE idCorso=" + id + ";";

        List<CorsoRicerca> corsoRicerca = this.jdbcTemplate.query(sb.toString(),
                new RowMapper<CorsoRicerca>() {
            @Override
            public CorsoRicerca mapRow(ResultSet rs, int rowNum) throws SQLException {
                CorsoRicerca corsoRicerca = new CorsoRicerca(rs.getInt("idCorso"),
                        rs.getString("titolo"),
                        rs.getString("descrizione"),
                        rs.getString("nomeCategoria"),
                        rs.getString("coordinate"),
                        rs.getString("durata"),
                        rs.getString("indirizzo"),
                        rs.getString("nomeStato"),
                        rs.getString("nomeRegione"),
                        rs.getString("foto")
                );
                return corsoRicerca;
            }
        });
        return corsoRicerca.get(0);
    }

    public int numeroCorsi() {
        SqlRowSet rs = this.jdbcTemplate.queryForRowSet("SELECT COUNT(*) AS n_corsi FROM Corso;");
        if (rs.next()) {
            return rs.getInt(1);
        }
        return 0;
    }

    public int numeroUtenti() {
        SqlRowSet rs = this.jdbcTemplate.queryForRowSet("SELECT COUNT(*) AS n_utenti FROM Utente;");
        if (rs.next()) {
            return rs.getInt(1);
        }
        return 0;
    }

    public int numeroRecensioni() {
        SqlRowSet rs = this.jdbcTemplate.queryForRowSet("SELECT COUNT(*) AS n_recensioni FROM Recensione;");
        if (rs.next()) {
            return rs.getInt(1);
        }
        return 0;
    }

    public boolean isRegistred(String email) {
        SqlRowSet rs = this.jdbcTemplate.queryForRowSet("SELECT COUNT(*) AS n FROM Utente WHERE mail LIKE \"" + email + "\";");
        if (rs.next()) {
            int n = rs.getInt(1);
            if (n == 1) {
                return true;
            }
        }
        return false;
    }

    public Utente utenteByEmail(String email) {
        String sb = "SELECT * FROM Utente WHERE mail LIKE \"" + email + "\";";
        List<Utente> utente = this.jdbcTemplate.query(sb,
                new RowMapper<Utente>() {
            @Override
            public Utente mapRow(ResultSet rs, int rowNum) throws SQLException {
                Utente utente = new Utente(
                        rs.getInt("idUtente"),
                        rs.getString("nome"),
                        rs.getString("cognome"),
                        rs.getString("foto"),
                        rs.getString("mail"),
                        rs.getString("password"),
                        rs.getString("username")
                );
                return utente;
            }
        });
        return utente.get(0);
    }

    public void addUtente(String email, String username, String nome, String cognome, String foto, String password) {
        System.out.println("QUI");
        String sql = "INSERT INTO Utente "
                + "(mail, nome, cognome, username, password, foto)"
                + " VALUES (?,?,?,?,?,?)";

        System.out.println(Arrays.toString(new Object[]{
            email,
            nome,
            cognome,
            username,
            password,
            foto
        }));
        this.jdbcTemplate.update(sql, new Object[]{
            email,
            nome,
            cognome,
            username,
            password,
            foto
        });

    }

    public Utente utenteById(int id) {
        String sb = "SELECT * FROM Utente WHERE idUtente = " + id + ";";
        List<Utente> utente = this.jdbcTemplate.query(sb,
                new RowMapper<Utente>() {
            @Override
            public Utente mapRow(ResultSet rs, int rowNum) throws SQLException {
                Utente utente = new Utente(
                        rs.getInt("idUtente"),
                        rs.getString("nome"),
                        rs.getString("cognome"),
                        rs.getString("foto"),
                        rs.getString("mail"),
                        "",
                        rs.getString("username")
                );
                return utente;
            }
        });
        return utente.get(0);
    }

    public void updateUser(int id, String nome, String cognome, String password) {
        String sql = "UPDATE Utente "
                + "SET nome=?, cognome=?,password=?"
                + " WHERE idUtente = ?";
        this.jdbcTemplate.update(sql, new Object[]{
            nome,
            cognome,
            password,
            id
        });
    }

    public void addRecensione(int idCorso, int idUtente, String titolo, String descrizione, String data, int valutazione) {
        String sql = "INSERT INTO Recensione "
                + "(fkIdCorso,fkIdUtente, titolo, commento, dataFrequentazione, valutazione)"
                + " VALUES (?,?,?,?,?,?)";

        this.jdbcTemplate.update(sql, new Object[]{
            idCorso,
            idUtente,
            titolo,
            descrizione,
            data,
            valutazione
        });
    }

    public List<Regione> listaRegioni() {
        List<Regione> regione = this.jdbcTemplate.query(
                "SELECT Regione.idRegione, Regione.nomeRegione\n"
                + "FROM Regione;",
                new RowMapper<Regione>() {
            @Override
            public Regione mapRow(ResultSet rs, int rowNum) throws SQLException {
                Regione regione = new Regione();
                regione.setByDB(
                        rs.getInt("idRegione"),
                        rs.getString("nomeRegione"),
                        new Stato()
                );
                return regione;
            }
        });
        return regione;
    }



    public int addCorso(String titolo, String descrizione, String coordinate, String regione, String categoria, String indirizzo, String durata) {
        String sql = "INSERT INTO Corso "
                + "(fkIdRegione,fkIdCategoria, titolo, descrizione, coordinate, indirizzo, durata)"
                + " VALUES (?,?,?,?,?,?,?)";

        return this.jdbcTemplate.update(sql, new Object[]{
            regione,
            categoria,
            titolo,
            descrizione,
            coordinate,
            indirizzo,
            durata
        });
        
    }

}
