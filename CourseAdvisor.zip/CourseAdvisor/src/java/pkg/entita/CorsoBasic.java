/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;

/**
 *
 * @author Nicolò Barbato
 */
public class CorsoBasic {
    int idCorso;
    String titolo;

    public CorsoBasic() {
    }
    

    public CorsoBasic(int idCorso, String titolo) {
        this.idCorso = idCorso;
        this.titolo = titolo;
    }
    
}
