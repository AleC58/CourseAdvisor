/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;

/**
 *
 * @author marco.cabianca
 */
public class CorsoRicerca {
	
	int idCorso;
	String titolo;
	String descrizione;
	String nomeCategoria;
	String coordinate;
	String durata;
	String indirizzo;
	String nomeStato;
	String nomeRegione;
        String foto;

    public CorsoRicerca() {
        titolo="Pippo";
    }

        
	public CorsoRicerca(int idCorso, String titolo, String descrizione, String nomeCategoria, String coordinate, String durata, String indirizzo, String nomeStato, String nomeRegione, String foto) {
		this.idCorso = idCorso;
		this.titolo = titolo;
		this.descrizione = descrizione;
		this.nomeCategoria = nomeCategoria;
		this.coordinate = coordinate;
		this.durata = durata;
		this.indirizzo = indirizzo;
		this.nomeStato = nomeStato;
		this.nomeRegione = nomeRegione;
                this.foto=foto;
	}

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
        
        

    public int getIdCorso() {
        return idCorso;
    }

    public void setIdCorso(int idCorso) {
        this.idCorso = idCorso;
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getNomeCategoria() {
        return nomeCategoria;
    }

    public void setNomeCategoria(String nomeCategoria) {
        this.nomeCategoria = nomeCategoria;
    }

    public String getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(String coordinate) {
        this.coordinate = coordinate;
    }

    public String getDurata() {
        return durata;
    }

    public void setDurata(String durata) {
        this.durata = durata;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    public String getNomeStato() {
        return nomeStato;
    }

    public void setNomeStato(String nomeStato) {
        this.nomeStato = nomeStato;
    }

    public String getNomeRegione() {
        return nomeRegione;
    }

    public void setNomeRegione(String nomeRegione) {
        this.nomeRegione = nomeRegione;
    }
        
        




	
}
