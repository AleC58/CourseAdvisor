/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;

/**
 *
 * @author Nicolò Barbato
 */
public class CorsoHome {

    private String titolo, descrizione, posizione, foto;
    private String idCorso;

    public CorsoHome(int idCorso, String titolo, String descrizione, String posizione) {
        this.titolo = titolo;
        this.descrizione = descrizione;
        this.posizione = posizione;
        this.idCorso = Integer.toString(idCorso);
    }

    public String getIdCorso() {
        return idCorso;
    }

    public void setIdCorso(int idCorso) {
        this.idCorso = Integer.toString(idCorso);
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getPosizione() {
        return posizione;
    }

    public void setPosizione(String posizione) {
        this.posizione = posizione;
    }

}
