/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;

/**
 *
 * @author marco.cabianca
 */
public class Corso {
	int idCorso;
	String titolo,descrizione,coordinate,indirizzo;
	int durata;
	Regione regione;
	CategoriaBasic categoria;

	public Corso() {
	}	

	public void setByDB(int idCorso, String titolo, String descrizione, String coordinate, String indirizzo, int durata, Regione regione, CategoriaBasic categoria) {
		this.idCorso = idCorso;
		this.titolo = titolo;
		this.descrizione = descrizione;
		this.coordinate = coordinate;
		this.indirizzo = indirizzo;
		this.durata = durata;
		this.regione = regione;
		this.categoria = categoria;
	}	
	
}


