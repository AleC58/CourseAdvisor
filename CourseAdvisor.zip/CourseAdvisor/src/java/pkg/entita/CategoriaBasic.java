/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;

/**
 *
 * @author marco.cabianca
 */
public class CategoriaBasic {
	int idCategoria;
	String categoria;

	public CategoriaBasic() {
	}

	public void setByDB(int idCategoria, String categoria) {
		this.idCategoria = idCategoria;
		this.categoria = categoria;
	}

	public int getIdCategoria() {
		return idCategoria;
	}

	public String getCategoria() {
		return categoria;
	}
	
	
}
