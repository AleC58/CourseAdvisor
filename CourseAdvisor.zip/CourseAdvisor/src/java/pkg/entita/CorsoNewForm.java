/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;

/**
 *
 * @author diego
 */
public class CorsoNewForm {
    private int  idCorso;
    private String titolo, descrizione, categoria, coordinate, indirizzo, stato , regione, durata;
;

    public CorsoNewForm() {
    }

    public int getIdCorso() {
        return idCorso;
    }

    public void setIdCorso(int idCorso) {
        this.idCorso = idCorso;
    }

    public String getDurata() {
        return durata;
    }

    public void setDurata(String durata) {
        this.durata = durata;
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(String coordinate) {
        this.coordinate = coordinate;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    public String getStato() {
        return stato;
    }

    public void setStato(String stato) {
        this.stato = stato;
    }

    public String getRegione() {
        return regione;
    }

    public void setRegione(String regione) {
        this.regione = regione;
    }


    public void setByDB(int idCorso, String durata, String titolo, String descrizione, String categoria, String coordinate, String indirizzo, String stato, String regione) {
        this.idCorso = idCorso;
        this.durata = durata;
        this.titolo = titolo;
        this.descrizione = descrizione;
        this.categoria = categoria;
        this.coordinate = coordinate;
        this.indirizzo = indirizzo;
        this.stato = stato;
        this.regione = regione;
    }
    
    
}
