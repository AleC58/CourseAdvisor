/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;

/**
 *
 * @author marco.cabianca
 */
public class Stato {
	int idStato;
	String nomeStato;

	public Stato() {
	}

	public void setByDB(int idStato, String nomeStato) {
		this.idStato = idStato;
		this.nomeStato = nomeStato;
	}

	public int getIdStato() {
		return idStato;
	}

	public String getNomeStato() {
		return nomeStato;
	}
	
	
	
}
