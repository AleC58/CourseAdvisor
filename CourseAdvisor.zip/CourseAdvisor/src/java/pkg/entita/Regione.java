/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;

/**
 *
 * @author marco.cabianca
 */
public class Regione {
	
	int idRegione;
	String nomeRegione;
	Stato stato;

	public Regione() {
	}

	public void setByDB(int idRegione, String nomeRegione, Stato stato) {
		this.idRegione = idRegione;
		this.nomeRegione = nomeRegione;
		this.stato = stato;
	}

	public int getIdRegione() {
		return idRegione;
	}

	public void setIdRegione(int idRegione) {
		this.idRegione = idRegione;
	}

	public String getNomeRegione() {
		return nomeRegione;
	}

	public void setNomeRegione(String nomeRegione) {
		this.nomeRegione = nomeRegione;
	}
	
	
	
	
}
