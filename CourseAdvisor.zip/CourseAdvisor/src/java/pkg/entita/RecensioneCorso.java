/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;

/**
 *
 * @author Nicolò Barbato
 */
public class RecensioneCorso {

    int idRecensione,idUtente;


    String titolo;
    int valutazione;
    String commento;
    String dataFrequentazione;
    String cognome;
    String nome;
    String foto;

    public RecensioneCorso(int idRecensione, int idUtente, String titolo, int valutazione, String commento, String dataFrequentazione, String cognome, String nome, String foto) {
        this.idRecensione = idRecensione;
        this.idUtente = idUtente;
        this.titolo = titolo;
        this.valutazione = valutazione;
        this.commento = commento;
        this.dataFrequentazione = dataFrequentazione;
        this.cognome = cognome;
        this.nome = nome;
        this.foto = foto;
    }

		public int getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(int idUtente) {
		this.idUtente = idUtente;
	}
    public int getIdRecensione() {
        return idRecensione;
    }

    public void setIdRecensione(int idRecensione) {
        this.idRecensione = idRecensione;
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public int getValutazione() {
        return valutazione;
    }

    public void setValutazione(int valutazione) {
        this.valutazione = valutazione;
    }

    public String getCommento() {
        return commento;
    }

    public void setCommento(String commento) {
        this.commento = commento;
    }

    public String getDataFrequentazione() {
        return dataFrequentazione;
    }

    public void setDataFrequentazione(String dataFrequentazione) {
        this.dataFrequentazione = dataFrequentazione;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

}
