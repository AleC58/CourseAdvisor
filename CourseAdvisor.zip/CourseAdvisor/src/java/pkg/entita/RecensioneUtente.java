/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;

/**
 *
 * @author marco.cabianca
 */
public class RecensioneUtente {
	
	int idRecensione;
    String titoloRec;
    int idCorso;
    String titoloCorso;
    int valutazione;
    String commento;
    String dataFrequentazione;

	public RecensioneUtente() {
	}

	public RecensioneUtente(int idRecensione, String titoloRec, int idCorso, String titoloCorso, int valutazione, String commento, String dataFrequentazione) {
		this.idRecensione = idRecensione;
		this.titoloRec = titoloRec;
		this.idCorso = idCorso;
		this.titoloCorso = titoloCorso;
		this.valutazione = valutazione;
		this.commento = commento;
		this.dataFrequentazione = dataFrequentazione;
	}



	public int getIdRecensione() {
		return idRecensione;
	}

	public void setIdRecensione(int idRecensione) {
		this.idRecensione = idRecensione;
	}

	public String getTitoloRec() {
		return titoloRec;
	}

	public void setTitoloRec(String titoloRec) {
		this.titoloRec = titoloRec;
	}

	public int getIdCorso() {
		return idCorso;
	}

	public void setIdCorso(int idCorso) {
		this.idCorso = idCorso;
	}

	public String getTitoloCorso() {
		return titoloCorso;
	}

	public void setTitoloCorso(String titoloCorso) {
		this.titoloCorso = titoloCorso;
	}

	public int getValutazione() {
		return valutazione;
	}

	public void setValutazione(int valutazione) {
		this.valutazione = valutazione;
	}

	public String getCommento() {
		return commento;
	}

	public void setCommento(String commento) {
		this.commento = commento;
	}

	public String getDataFrequentazione() {
		return dataFrequentazione;
	}

	public void setDataFrequentazione(String dataFrequentazione) {
		this.dataFrequentazione = dataFrequentazione;
	}

	

	
	
	
}
