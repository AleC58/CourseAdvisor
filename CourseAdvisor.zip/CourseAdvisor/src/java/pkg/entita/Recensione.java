/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;

/**
 *
 * @author Nicolò Barbato
 */
public class Recensione {
    
    int idRecensione;
    String titolo;
    int valutazione;
    String commento;
    String dataFrequentazione;
    Utente utente;
    Corso corso;

    public Recensione() {
        
    }

    public Recensione(int idRecensione, String titolo, int valutazione, String commento, String dataFrequentazione, Utente utente, Corso corso) {
        this.idRecensione = idRecensione;
        this.titolo = titolo;
        this.valutazione = valutazione;
        this.commento = commento;
        this.dataFrequentazione = dataFrequentazione;
        this.utente = utente;
        this.corso = corso;
    }

    
}
