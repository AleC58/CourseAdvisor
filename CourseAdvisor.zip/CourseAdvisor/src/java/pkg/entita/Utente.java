/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;



import java.io.Serializable;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

/**
 *
 * @author marco.cabianca
 */
@Component
@Scope(value = "session",proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Utente implements Serializable {
	protected int id;
	protected boolean isLogged = false;
	protected String nome, cognome, foto, mail, password, username;

	public Utente() {
		nome = null;
		cognome=null;
		foto=null;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Utente(int id, String nome, String cognome, String foto, String mail, String password, String username) {
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
		this.foto = foto;
		this.mail = mail;
		this.password = password;
		this.username = username;
	}
	

	public boolean isIsLogged() {
		return isLogged;
	}

	public void setIsLogged(boolean isLogged) {
		this.isLogged = isLogged;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void login() {
		
		this.isLogged = true;
	}
	
	public void logout() {
		this.isLogged = false;
	}

	public boolean isLogged() {
		return isLogged;
	}

    @Override
    public String toString() {
        return "Utente{" + "id=" + id + ", isLogged=" + isLogged + ", nome=" + nome + ", cognome=" + cognome + ", foto=" + foto + ", mail=" + mail + ", password=" + password + ", username=" + username + '}';
    }

}
