/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg.entita;

/**
 *
 * @author marco.cabianca
 */
public class UtenteEditForm extends Utente{
	private String repassword;

    public UtenteEditForm() {
    }
        
        
	public UtenteEditForm(Utente u) {
		this.cognome=u.cognome;
		this.nome=u.nome;
		this.foto=u.foto;
		this.mail=u.mail;
		this.username=u.username;
                this.password="";
                this.id=u.id;
	}
        

    public String getRepassword() {
        return repassword;
    }

    public void setRepassword(String repassword) {
        this.repassword = repassword;
    }
        
	
}
