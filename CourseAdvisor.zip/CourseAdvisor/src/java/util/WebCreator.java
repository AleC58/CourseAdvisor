/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author marco.cabianca
 */
public class WebCreator {

    public String getCSS() {
        String css = "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">"
                + "<link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\"/>"
                + "<link rel=\"stylesheet\" href=\"css/font-awesome.min.css\">"
                + "<link href=\"https://fonts.googleapis.com/css?family=Kaushan+Script\" rel=\"stylesheet\"> "
                + "<meta name=\"viewport\" content=\"width = device-width, initial-scale = 1\">"
                + "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js\"></script>\n"
                + "<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js\"></script>"
                + "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\""
                + " integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">"
                + "<title>CourseAdvisor</title>";
        return css;
    }

    public String getUserBar() {
        String bar = "<div id=\"userBar\">"
                + "                    <div class=\"userOption\">"
                + "                       <c:if test=\"${utente.isLogged()}\">"
                + "                           <p>Ciao ${utente.getNome()}</p>"
                + "                           <a href=\"logout\">Esci</a>"
                + "                       </c:if>"
                + "                       <c:if test=\"${!utente.isLogged()}\">"
                + "                           <a href=\"login\">Accedi</a>"
                + "                       </c:if>	"
                + "                   </div>"
                + "</div>";
        return bar;
    }

    public String getFooter() {
        String footer = "<div class=\"row\">\n"
                + "                    <div class=\"separatore col-md-12\"></div>\n"
                + "                    <div id=\"footer\" class=\"col-md-12\">\n"
                + "                        <p>Marco Cabianca - Nicolo' Barbato - Diego De Mattia</p>\n"
                + "\n"
                + "                    </div>\n"
                + "                </div>";
        return footer;
    }

}
